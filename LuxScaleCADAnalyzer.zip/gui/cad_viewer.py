from PySide6.QtWidgets import QGraphicsView
from PySide6.QtGui import QPainter, QPen, QBrush
from PySide6.QtCore import Qt


class CADViewer(QGraphicsView):

    def __init__(

        self,

        parent=None
    ):

        super().__init__(

            parent
        )

        self.entities = []

        self.rooms = []

        self.selected_room = None

        self.setRenderHint(

            QPainter.RenderHint.Antialiasing
        )

        self.setDragMode(

            QGraphicsView.DragMode.ScrollHandDrag
        )

    def set_cad_data(

        self,

        entities,

        rooms
    ):

        self.entities = entities

        self.rooms = rooms

        self.selected_room = None

        self.viewport().update()

    def paintEvent(

        self,

        event
    ):

        painter = QPainter(

            self.viewport()
        )

        painter.setRenderHint(

            QPainter.RenderHint.Antialiasing
        )

        if not self.entities and not self.rooms:

            painter.drawText(

                30,

                40,

                "No CAD geometry loaded"
            )

            return

        all_points = []

        for entity in self.entities:

            if not entity:

                continue

            if entity["type"] == "LINE":

                all_points.append(

                    entity["start"]
                )

                all_points.append(

                    entity["end"]
                )

            elif entity["type"] == "POLYLINE":

                all_points.extend(

                    entity["points"]
                )

        for room in self.rooms:

            all_points.extend(

                room["points"]
            )

        if not all_points:

            return

        min_x = min(

            p[0]

            for p in all_points
        )

        max_x = max(

            p[0]

            for p in all_points
        )

        min_y = min(

            p[1]

            for p in all_points
        )

        max_y = max(

            p[1]

            for p in all_points
        )

        width = max_x - min_x

        height = max_y - min_y

        if width <= 0:

            width = 1

        if height <= 0:

            height = 1

        viewport_width = (

            self.viewport().width()
        )

        viewport_height = (

            self.viewport().height()
        )

        margin = 50

        scale_x = (

            viewport_width - margin * 2
        ) / width

        scale_y = (

            viewport_height - margin * 2
        ) / height

        scale = min(

            scale_x,

            scale_y
        )

        def transform(

            point
        ):

            x = (

                point[0]

                -

                min_x
            ) * scale + margin

            y = (

                max_y

                -

                point[1]
            ) * scale + margin

            return x, y

        # -------------------------------------------------
        # DRAW CAD ENTITIES
        # -------------------------------------------------

        painter.setPen(

            QPen(

                Qt.GlobalColor.darkGray,

                1
            )
        )

        for entity in self.entities:

            if not entity:

                continue

            if entity["type"] == "LINE":

                p1 = transform(

                    entity["start"]
                )

                p2 = transform(

                    entity["end"]
                )

                painter.drawLine(

                    int(p1[0]),

                    int(p1[1]),

                    int(p2[0]),

                    int(p2[1])
                )

            elif entity["type"] == "POLYLINE":

                points = [

                    transform(p)

                    for p in entity["points"]
                ]

                for i in range(

                    len(points) - 1
                ):

                    painter.drawLine(

                        int(points[i][0]),

                        int(points[i][1]),

                        int(points[i + 1][0]),

                        int(points[i + 1][1])
                    )

        # -------------------------------------------------
        # DRAW DETECTED ROOMS
        # -------------------------------------------------

        painter.setPen(

            QPen(

                Qt.GlobalColor.blue,

                2
            )
        )

        for room in self.rooms:

            points = [

                transform(p)

                for p in room["points"]
            ]

            for i in range(

                len(points)
            ):

                p1 = points[i]

                p2 = points[

                    (

                        i + 1

                    )

                    %

                    len(points)
                ]

                painter.drawLine(

                    int(p1[0]),

                    int(p1[1]),

                    int(p2[0]),

                    int(p2[1])
                )

            center = transform(

                room["centroid"]
            )

            painter.drawText(

                int(center[0]),

                int(center[1]),

                (

                    f"Room {room['id']}\n"

                    f"{room['area']} m²"
                )
            )