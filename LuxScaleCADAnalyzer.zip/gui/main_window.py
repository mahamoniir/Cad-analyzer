import json

from PySide6.QtWidgets import (

    QMainWindow,

    QWidget,

    QVBoxLayout,

    QHBoxLayout,

    QPushButton,

    QLabel,

    QFileDialog,

    QComboBox,

    QDoubleSpinBox,

    QLineEdit,

    QTableWidget,

    QTableWidgetItem,

    QTextEdit,

    QSplitter,

    QMessageBox
)

from PySide6.QtCore import Qt

from cad_analyzer.dwg_reader import DWGReader

from gui.cad_viewer import CADViewer

from luxscale_client import LuxScaleClient


class MainWindow(QMainWindow):

    def __init__(self):

        super().__init__()

        self.setWindowTitle(

            "LuxScale CAD Analyzer"
        )

        self.resize(

            1600,

            950
        )

        self.reader = None

        self.rooms = []

        self.current_room = None

        self.places = {}

        self.category_keywords = {}

        self.client = (

            LuxScaleClient(

                "http://127.0.0.1:5000"
            )
        )

        self.build_ui()

        self.load_places()

    # =====================================================
    # UI
    # =====================================================

    def build_ui(self):

        central = QWidget()

        self.setCentralWidget(

            central
        )

        root = QVBoxLayout(

            central
        )

        title = QLabel(

            "LuxScale CAD Analyzer"
        )

        title.setStyleSheet(

            "font-size: 28px; font-weight: bold;"
        )

        root.addWidget(

            title
        )

        # -------------------------------------------------
        # FILE BAR
        # -------------------------------------------------

        file_layout = QHBoxLayout()

        self.file_label = QLabel(

            "No CAD file selected"
        )

        select_button = QPushButton(

            "Select CAD File"
        )

        select_button.clicked.connect(

            self.select_file
        )

        analyze_button = QPushButton(

            "Analyze CAD"
        )

        analyze_button.clicked.connect(

            self.analyze_cad
        )

        file_layout.addWidget(

            self.file_label
        )

        file_layout.addWidget(

            select_button
        )

        file_layout.addWidget(

            analyze_button
        )

        root.addLayout(

            file_layout
        )

        # -------------------------------------------------
        # SUMMARY
        # -------------------------------------------------

        self.summary_label = QLabel(

            "No CAD analyzed"
        )

        root.addWidget(

            self.summary_label
        )

        # -------------------------------------------------
        # MAIN SPLITTER
        # -------------------------------------------------

        splitter = QSplitter(

            Qt.Orientation.Horizontal
        )

        root.addWidget(

            splitter,

            1
        )

        # =================================================
        # LEFT SIDE
        # =================================================

        left = QWidget()

        left_layout = QVBoxLayout(

            left
        )

        left_layout.addWidget(

            QLabel(

                "CAD Drawing"
            )
        )

        self.viewer = CADViewer()

        left_layout.addWidget(

            self.viewer,

            2
        )

        left_layout.addWidget(

            QLabel(

                "Detected Rooms"
            )
        )

        self.room_table = QTableWidget()

        self.room_table.setColumnCount(

            7
        )

        self.room_table.setHorizontalHeaderLabels(

            [

                "ID",

                "Layer",

                "Area (m²)",

                "Width (m)",

                "Length (m)",

                "Sides",

                "Perimeter"
            ]
        )

        self.room_table.cellClicked.connect(

            self.room_selected
        )

        left_layout.addWidget(

            self.room_table,

            1
        )

        splitter.addWidget(

            left
        )

        # =================================================
        # RIGHT SIDE
        # =================================================

        right = QWidget()

        right_layout = QVBoxLayout(

            right
        )

        right_layout.addWidget(

            QLabel(

                "Selected Room"
            )
        )

        self.selected_room_label = QLabel(

            "No room selected"
        )

        right_layout.addWidget(

            self.selected_room_label
        )

        self.side_labels = []

        for i in range(

            4
        ):

            label = QLabel(

                f"Side {i + 1}: -"
            )

            self.side_labels.append(

                label
            )

            right_layout.addWidget(

                label
            )

        self.area_label = QLabel(

            "Area: -"
        )

        right_layout.addWidget(

            self.area_label
        )

        # -------------------------------------------------
        # HEIGHT
        # -------------------------------------------------

        right_layout.addWidget(

            QLabel(

                "Ceiling Height (m)"
            )
        )

        self.height_input = QDoubleSpinBox()

        self.height_input.setRange(

            0.1,

            100
        )

        self.height_input.setValue(

            3.2
        )

        self.height_input.setDecimals(

            2
        )

        right_layout.addWidget(

            self.height_input
        )

        # -------------------------------------------------
        # PLACE
        # -------------------------------------------------

        right_layout.addWidget(

            QLabel(

                "Room Type"
            )
        )

        self.place_combo = QComboBox()

        self.place_combo.currentTextChanged.connect(

            self.place_changed
        )

        right_layout.addWidget(

            self.place_combo
        )

        self.required_lux_label = QLabel(

            "Required Lux: -"
        )

        right_layout.addWidget(

            self.required_lux_label
        )

        self.uniformity_label = QLabel(

            "Uniformity: -"
        )

        right_layout.addWidget(

            self.uniformity_label
        )

        self.category_label = QLabel(

            "Standard Category: -"
        )

        self.category_label.setWordWrap(

            True
        )

        right_layout.addWidget(

            self.category_label
        )

        # -------------------------------------------------
        # STANDARD REF
        # -------------------------------------------------

        right_layout.addWidget(

            QLabel(

                "Standard Reference"
            )
        )

        self.standard_ref_input = QLineEdit()

        right_layout.addWidget(

            self.standard_ref_input
        )

        # -------------------------------------------------
        # PROJECT NAME
        # -------------------------------------------------

        right_layout.addWidget(

            QLabel(

                "Project Name"
            )
        )

        self.project_name_input = QLineEdit(

            "CAD Lighting Analysis"
        )

        right_layout.addWidget(

            self.project_name_input
        )

        # -------------------------------------------------
        # CALCULATE
        # -------------------------------------------------

        self.calculate_button = QPushButton(

            "Calculate Lighting"
        )

        self.calculate_button.setEnabled(

            False
        )

        self.calculate_button.clicked.connect(

            self.calculate_lighting
        )

        right_layout.addWidget(

            self.calculate_button
        )

        right_layout.addWidget(

            QLabel(

                "Calculation Result"
            )
        )

        self.result_text = QTextEdit()

        self.result_text.setReadOnly(

            True
        )

        right_layout.addWidget(

            self.result_text,

            1
        )

        splitter.addWidget(

            right
        )

        splitter.setSizes(

            [

                900,

                600
            ]
        )

    # =====================================================
    # LOAD API DATA
    # =====================================================

    def load_places(self):

        try:

            data = (

                self.client.get_places()
            )

            self.place_combo.clear()

            self.places = {}

            for place in data.get(

                "calculator_places",

                []
            ):

                name = (

                    place.get(

                        "key"
                    )
                )

                if not name:

                    continue

                self.places[name] = place

                self.place_combo.addItem(

                    name
                )

            self.category_keywords = (

                data.get(

                    "category_keywords",

                    {}
                )
            )

            self.place_changed(

                self.place_combo.currentIndex()
            )

        except Exception as error:

            QMessageBox.warning(

                self,

                "API Error",

                (

                    "Could not load places from LuxScale API:\n"

                    f"{error}"
                )
            )

    # =====================================================
    # SELECT FILE
    # =====================================================

    def select_file(self):

        file_path, _ = QFileDialog.getOpenFileName(

            self,

            "Select CAD File",

            "",

            "CAD Files (*.dxf *.dwg);;All Files (*)"
        )

        if file_path:

            self.file_label.setText(

                file_path
            )

    # =====================================================
    # ANALYZE CAD
    # =====================================================

    def analyze_cad(self):

        file_path = (

            self.file_label.text()
        )

        if not file_path or file_path == "No CAD file selected":

            QMessageBox.warning(

                self,

                "No File",

                "Please select a CAD file first."
            )

            return

        try:

            self.reader = DWGReader(

                file_path
            )

            self.reader.load()

            self.rooms = (

                self.reader.detect_rooms()
            )

            draw_data = (

                self.reader.get_draw_data()
            )

            self.viewer.set_cad_data(

                draw_data["entities"],

                self.rooms
            )

            self.populate_rooms()

            summary = (

                self.reader.get_summary()
            )

            self.summary_label.setText(

                (

                    f"Layers: {summary['layers']}    "

                    f"Entities: {summary['entities']}    "

                    f"Rooms: {len(self.rooms)}"
                )
            )

            if not self.rooms:

                QMessageBox.warning(

                    self,

                    "No Rooms Detected",

                    (

                        "The CAD file was loaded successfully, "

                        "but no closed room boundaries were detected.\n\n"

                        "The drawing will still be displayed graphically."
                    )
                )

        except Exception as error:

            QMessageBox.critical(

                self,

                "CAD Error",

                str(error)
            )

    # =====================================================
    # POPULATE ROOM TABLE
    # =====================================================

    def populate_rooms(self):

        self.room_table.setRowCount(

            0
        )

        for row, room in enumerate(

            self.rooms
        ):

            self.room_table.insertRow(

                row
            )

            self.room_table.setItem(

                row,

                0,

                QTableWidgetItem(

                    str(

                        room["id"]
                    )
                )
            )

            self.room_table.setItem(

                row,

                1,

                QTableWidgetItem(

                    room["layer"]
                )
            )

            self.room_table.setItem(

                row,

                2,

                QTableWidgetItem(

                    str(

                        room["area"]
                    )
                )
            )

            self.room_table.setItem(

                row,

                3,

                QTableWidgetItem(

                    str(

                        room["width"]
                    )
                )
            )

            self.room_table.setItem(

                row,

                4,

                QTableWidgetItem(

                    str(

                        room["length"]
                    )
                )
            )

            self.room_table.setItem(

                row,

                5,

                QTableWidgetItem(

                    ", ".join(

                        str(

                            side
                        )

                        for side in room["sides"]
                    )
                )
            )

            self.room_table.setItem(

                row,

                6,

                QTableWidgetItem(

                    str(

                        room["perimeter"]
                    )
                )
            )

    # =====================================================
    # ROOM SELECTED
    # =====================================================

    def room_selected(

        self,

        row,

        column
    ):

        if row < 0 or row >= len(

            self.rooms
        ):

            return

        self.current_room = (

            self.rooms[row]
        )

        room = (

            self.current_room
        )

        self.selected_room_label.setText(

            (

                f"Room {room['id']} | "

                f"{room['area']} m²"
            )
        )

        sides = (

            room["sides"]
        )

        for i, label in enumerate(

            self.side_labels
        ):

            if i < len(sides):

                label.setText(

                    (

                        f"Side {i + 1}: "

                        f"{sides[i]} m"
                    )
                )

            else:

                label.setText(

                    f"Side {i + 1}: -"
                )

        self.area_label.setText(

            f"Area: {room['area']} m²"
        )

        self.calculate_button.setEnabled(

            True
        )

    # =====================================================
    # PLACE CHANGED
    # =====================================================

    def place_changed(

        self,

        text
    ):

        place = (

            self.places.get(

                text,

                {}
            )
        )

        self.required_lux_label.setText(

            (

                f"Required Lux: "

                f"{place.get('lux', '-')}"
            )
        )

        self.uniformity_label.setText(

            (

                f"Uniformity: "

                f"{place.get('uniformity', '-')}"
            )
        )

        category = (

            self.find_category(

                text
            )
        )

        self.category_label.setText(

            (

                f"Standard Category: "

                f"{category}"
            )
        )

    # =====================================================
    # FIND STANDARD CATEGORY
    # =====================================================

    def find_category(

        self,

        place_name
    ):

        search_text = (

            place_name.lower()
        )

        for category, keywords in (

            self.category_keywords.items()
        ):

            if search_text in category.lower():

                return category

            for keyword in keywords:

                if keyword.lower() in search_text:

                    return category

        return "No category matched"

    # =====================================================
    # CALCULATE
    # =====================================================

    def calculate_lighting(self):

        if not self.current_room:

            QMessageBox.warning(

                self,

                "No Room Selected",

                "Select a detected room first."
            )

            return

        room = (

            self.current_room
        )

        place = (

            self.place_combo.currentText()
        )

        standard_ref = (

            self.standard_ref_input.text().strip()
        )

        try:

            result = (

                self.client.calculate(

                    sides=room["sides"],

                    height=self.height_input.value(),

                    place=place,

                    standard_ref_no=standard_ref

                    if standard_ref

                    else None,

                    project_name=(

                        self.project_name_input.text()
                    ),

                    fast=False
                )
            )

            self.result_text.setPlainText(

                json.dumps(

                    result,

                    indent=4,

                    ensure_ascii=False
                )
            )

        except Exception as error:

            QMessageBox.critical(

                self,

                "Calculation Error",

                str(error)
            )