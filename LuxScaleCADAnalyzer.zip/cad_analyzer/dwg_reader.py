from __future__ import annotations

from pathlib import Path
from typing import Optional
import math
import shutil
import subprocess
import tempfile

import ezdxf


class DWGReader:

    def __init__(
        self,
        file_path: str,
        oda_path: Optional[str] = None
    ):

        self.original_file_path = Path(file_path)

        self.oda_path = oda_path

        self.file_path = self.original_file_path

        self.doc = None

        self.modelspace = None

        self.entities = []

        self.layers = []

        self.converted_dxf_path = None

    # =========================================================
    # LOAD
    # =========================================================

    def load(self):

        if not self.original_file_path.exists():

            raise FileNotFoundError(

                f"CAD file not found:\n"
                f"{self.original_file_path}"
            )

        extension = (

            self.original_file_path
            .suffix
            .lower()
        )

        # -----------------------------------------------------
        # DWG → DXF THROUGH ODA
        # -----------------------------------------------------

        if extension == ".dwg":

            self.converted_dxf_path = (

                self.convert_dwg_to_dxf()
            )

            self.file_path = (

                Path(
                    self.converted_dxf_path
                )
            )

        elif extension == ".dxf":

            self.file_path = (

                self.original_file_path
            )

        else:

            raise ValueError(

                "Unsupported CAD file format. "
                "Only DWG and DXF are supported."
            )

        # -----------------------------------------------------
        # READ DXF WITH EZDXF
        # -----------------------------------------------------

        try:

            self.doc = ezdxf.readfile(

                str(
                    self.file_path
                )
            )

        except Exception as error:

            raise RuntimeError(

                f"Could not read converted DXF:\n"
                f"{error}"
            )

        self.modelspace = (

            self.doc.modelspace()
        )

        self.entities = list(

            self.modelspace
        )

        self.layers = [

            layer.dxf.name

            for layer in self.doc.layers
        ]

        return self

    # =========================================================
    # FIND ODA
    # =========================================================

    def find_oda_converter(self):

        possible_paths = [

            self.oda_path,

            r"C:\Program Files\ODA\ODAFileConverter\ODAFileConverter.exe",

            r"C:\Program Files\ODA\ODAFileConverter 26.5.0\ODAFileConverter.exe",

            r"C:\Program Files\ODA\ODAFileConverter 26.6.0\ODAFileConverter.exe",

            r"C:\Program Files\ODA\ODAFileConverter 27.0.0\ODAFileConverter.exe",

            r"C:\Program Files (x86)\ODA\ODAFileConverter\ODAFileConverter.exe",

            r"C:\Program Files (x86)\ODA\ODAFileConverter 26.5.0\ODAFileConverter.exe",

            r"C:\Program Files (x86)\ODA\ODAFileConverter 26.6.0\ODAFileConverter.exe",
        ]

        for path in possible_paths:

            if not path:

                continue

            path = Path(path)

            if path.exists():

                return str(path)

        return None

    # =========================================================
    # CONVERT DWG → DXF
    # =========================================================

    def convert_dwg_to_dxf(self):

        oda_exe = (

            self.find_oda_converter()
        )

        if not oda_exe:

            raise RuntimeError(

                "ODA File Converter was not found.\n\n"

                "Please install ODA File Converter or "
                "set the correct path in dwg_reader.py."
            )

        # -----------------------------------------------------
        # TEMPORARY WORKSPACE
        # -----------------------------------------------------

        temp_root = Path(

            tempfile.mkdtemp(

                prefix="luxscale_oda_"
            )
        )

        input_dir = (

            temp_root / "input"
        )

        output_dir = (

            temp_root / "output"
        )

        input_dir.mkdir()

        output_dir.mkdir()

        source_copy = (

            input_dir
            /

            self.original_file_path.name
        )

        shutil.copy2(

            self.original_file_path,

            source_copy
        )

        # -----------------------------------------------------
        # ODA COMMAND
        # -----------------------------------------------------

        command = [

            oda_exe,

            str(input_dir),

            str(output_dir),

            "ACAD2018",

            "DXF",

            "0",

            "1"
        ]

        try:

            result = subprocess.run(

                command,

                capture_output=True,

                text=True,

                timeout=180
            )

        except subprocess.TimeoutExpired:

            raise RuntimeError(

                "ODA File Converter timed out."
            )

        if result.returncode != 0:

            raise RuntimeError(

                "ODA File Converter failed.\n\n"

                f"STDOUT:\n{result.stdout}\n\n"

                f"STDERR:\n{result.stderr}"
            )

        # -----------------------------------------------------
        # FIND RESULT DXF
        # -----------------------------------------------------

        dxf_files = list(

            output_dir.glob(

                "*.dxf"
            )
        )

        if not dxf_files:

            raise RuntimeError(

                "ODA completed but no DXF file was created.\n\n"

                f"Output:\n{result.stdout}\n"

                f"Errors:\n{result.stderr}"
            )

        return str(

            dxf_files[0]
        )

    # =========================================================
    # SUMMARY
    # =========================================================

    def get_summary(self):

        rooms = (

            self.detect_rooms()
        )

        return {

            "file": str(

                self.original_file_path
            ),

            "converted_file": str(

                self.file_path
            ),

            "layers": len(

                self.layers
            ),

            "entities": len(

                self.entities
            ),

            "rooms": len(

                rooms
            )
        }

    # =========================================================
    # GEOMETRY
    # =========================================================

    @staticmethod
    def distance(

        p1,

        p2
    ):

        return math.sqrt(

            (

                p2[0] - p1[0]

            ) ** 2

            +

            (

                p2[1] - p1[1]

            ) ** 2
        )

    @staticmethod
    def same_point(

        p1,

        p2,

        tolerance=0.01
    ):

        return (

            DWGReader.distance(

                p1,

                p2
            )

            <= tolerance
        )

    # =========================================================
    # POLYLINE POINTS
    # =========================================================

    def extract_polyline(

        self,

        entity
    ):

        points = []

        try:

            if entity.dxftype() == "LWPOLYLINE":

                for point in entity.get_points():

                    points.append(

                        (

                            float(
                                point[0]
                            ),

                            float(
                                point[1]
                            )
                        )
                    )

            elif entity.dxftype() == "POLYLINE":

                for vertex in entity.vertices:

                    location = (

                        vertex.dxf.location
                    )

                    points.append(

                        (

                            float(
                                location.x
                            ),

                            float(
                                location.y
                            )
                        )
                    )

        except Exception:

            return []

        return points

    # =========================================================
    # CLOSED POLYLINES
    # =========================================================

    def detect_closed_polylines(self):

        rooms = []

        for index, entity in enumerate(

            self.entities
        ):

            entity_type = (

                entity.dxftype()
            )

            if entity_type not in [

                "LWPOLYLINE",

                "POLYLINE"
            ]:

                continue

            points = (

                self.extract_polyline(

                    entity
                )
            )

            if len(points) < 3:

                continue

            is_closed = False

            try:

                is_closed = bool(

                    entity.closed
                )

            except Exception:

                pass

            if not is_closed:

                if self.same_point(

                    points[0],

                    points[-1]
                ):

                    is_closed = True

            if not is_closed:

                continue

            if self.same_point(

                points[0],

                points[-1]
            ):

                points = points[:-1]

            area = (

                self.polygon_area(

                    points
                )
            )

            if area <= 0.01:

                continue

            room = (

                self.create_room(

                    index,

                    points,

                    entity
                )
            )

            rooms.append(

                room
            )

        return rooms

    # =========================================================
    # LINE-BASED ROOMS
    # =========================================================

    def detect_line_rooms(self):

        lines = []

        for index, entity in enumerate(

            self.entities
        ):

            if entity.dxftype() != "LINE":

                continue

            try:

                start = entity.dxf.start

                end = entity.dxf.end

                p1 = (

                    float(start.x),

                    float(start.y)
                )

                p2 = (

                    float(end.x),

                    float(end.y)
                )

                if self.distance(

                    p1,

                    p2
                ) < 0.001:

                    continue

                lines.append(

                    {

                        "index": index,

                        "start": p1,

                        "end": p2,

                        "entity": entity
                    }
                )

            except Exception:

                continue

        rooms = []

        used = set()

        for i, line in enumerate(

            lines
        ):

            if i in used:

                continue

            chain = [

                line["start"],

                line["end"]
            ]

            used.add(i)

            changed = True

            while changed:

                changed = False

                start_point = chain[0]

                end_point = chain[-1]

                for j, candidate in enumerate(

                    lines
                ):

                    if j in used:

                        continue

                    candidate_start = (

                        candidate["start"]
                    )

                    candidate_end = (

                        candidate["end"]
                    )

                    if self.same_point(

                        end_point,

                        candidate_start
                    ):

                        chain.append(

                            candidate_end
                        )

                        used.add(j)

                        changed = True

                        break

                    if self.same_point(

                        end_point,

                        candidate_end
                    ):

                        chain.append(

                            candidate_start
                        )

                        used.add(j)

                        changed = True

                        break

                    if self.same_point(

                        start_point,

                        candidate_end
                    ):

                        chain.insert(

                            0,

                            candidate_start
                        )

                        used.add(j)

                        changed = True

                        break

                    if self.same_point(

                        start_point,

                        candidate_start
                    ):

                        chain.insert(

                            0,

                            candidate_end
                        )

                        used.add(j)

                        changed = True

                        break

            if len(chain) < 4:

                continue

            if not self.same_point(

                chain[0],

                chain[-1]
            ):

                continue

            points = chain[:-1]

            area = (

                self.polygon_area(

                    points
                )
            )

            if area <= 0.01:

                continue

            rooms.append(

                self.create_room(

                    i,

                    points,

                    None
                )
            )

        return rooms

    # =========================================================
    # DETECT ROOMS
    # =========================================================

    def detect_rooms(self):

        rooms = []

        rooms.extend(

            self.detect_closed_polylines()
        )

        rooms.extend(

            self.detect_line_rooms()
        )

        return self.remove_duplicate_rooms(

            rooms
        )

    # =========================================================
    # REMOVE DUPLICATES
    # =========================================================

    def remove_duplicate_rooms(

        self,

        rooms
    ):

        unique = []

        keys = set()

        for room in rooms:

            key = (

                round(

                    room["area"],

                    2
                ),

                round(

                    room["centroid"][0],

                    2
                ),

                round(

                    room["centroid"][1],

                    2
                )
            )

            if key in keys:

                continue

            keys.add(

                key
            )

            unique.append(

                room
            )

        return unique

    # =========================================================
    # CREATE ROOM
    # =========================================================

    def create_room(

        self,

        index,

        points,

        entity
    ):

        area = (

            self.polygon_area(

                points
            )
        )

        sides = []

        perimeter = 0.0

        for i in range(

            len(points)
        ):

            p1 = points[i]

            p2 = points[

                (

                    i + 1

                )

                %

                len(points)
            ]

            length = (

                self.distance(

                    p1,

                    p2
                )
            )

            sides.append(

                round(

                    length,

                    3
                )
            )

            perimeter += length

        min_x = min(

            p[0]

            for p in points
        )

        max_x = max(

            p[0]

            for p in points
        )

        min_y = min(

            p[1]

            for p in points
        )

        max_y = max(

            p[1]

            for p in points
        )

        centroid = (

            sum(

                p[0]

                for p in points
            )

            /

            len(points),

            sum(

                p[1]

                for p in points
            )

            /

            len(points)
        )

        layer = "UNKNOWN"

        if entity is not None:

            try:

                layer = (

                    entity.dxf.layer
                )

            except Exception:

                pass

        return {

            "id": index + 1,

            "layer": layer,

            "area": round(

                area,

                3
            ),

            "width": round(

                max_x - min_x,

                3
            ),

            "length": round(

                max_y - min_y,

                3
            ),

            "perimeter": round(

                perimeter,

                3
            ),

            "sides": sides,

            "points": [

                [

                    round(

                        p[0],

                        4
                    ),

                    round(

                        p[1],

                        4
                    )

                ]

                for p in points
            ],

            "centroid": [

                round(

                    centroid[0],

                    4
                ),

                round(

                    centroid[1],

                    4
                )

            ]
        }

    # =========================================================
    # AREA
    # =========================================================

    @staticmethod
    def polygon_area(

        points
    ):

        area = 0.0

        for i in range(

            len(points)
        ):

            x1, y1 = points[i]

            x2, y2 = points[

                (

                    i + 1

                )

                %

                len(points)
            ]

            area += (

                x1 * y2

                -

                x2 * y1
            )

        return abs(

            area / 2.0
        )

    # =========================================================
    # DRAW DATA
    # =========================================================

    def get_draw_data(self):

        entities = []

        for entity in self.entities:

            data = (

                self.entity_to_draw_data(

                    entity
                )
            )

            if data:

                entities.append(

                    data
                )

        return {

            "layers": self.layers,

            "rooms": self.detect_rooms(),

            "entities": entities
        }

    # =========================================================
    # ENTITY DRAW DATA
    # =========================================================

    def entity_to_draw_data(

        self,

        entity
    ):

        entity_type = (

            entity.dxftype()
        )

        if entity_type == "LINE":

            try:

                start = entity.dxf.start

                end = entity.dxf.end

                return {

                    "type": "LINE",

                    "start": [

                        float(start.x),

                        float(start.y)
                    ],

                    "end": [

                        float(end.x),

                        float(end.y)
                    ]
                }

            except Exception:

                return None

        if entity_type in [

            "LWPOLYLINE",

            "POLYLINE"
        ]:

            points = (

                self.extract_polyline(

                    entity
                )
            )

            if len(points) >= 2:

                return {

                    "type": "POLYLINE",

                    "points": [

                        [

                            float(p[0]),

                            float(p[1])
                        ]

                        for p in points
                    ]
                }

        return None